# Translate plugin for Rocket League

## Install

[Through bakkes plugins](https://bakkesplugins.com/plugins/view/413)

## Settings

![image](https://github.com/0xleft/trnslt/assets/107749872/c69e1fb3-2c13-43a6-ae56-a0f7c2b738f3)

## Showcase

![image](https://github.com/0xleft/trnslt/assets/107749872/9b0c9920-6bf0-46e3-a95a-a879562da12b)


![image](https://github.com/0xleft/trnslt/assets/107749872/0504a702-6cfd-4548-ab00-ecacb1e2eb6c)
